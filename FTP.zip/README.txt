
Usage Instructions:

Push the "I found a panda" button if you've "found a panda"

Swipe left to see your own profile
Swipe right to see the scoreboard
Press on a panda to see details about the panda

Known bugs:

Pushing back after swiping left or right exits the app instead of making the
user go back to the home screen.

The map may not load due to problems with the API key.

Areas we want feedback on:

Is it natural to move throughout the app?

Do you think the game will be fun?

Would you actually play this?

What other features would you want to see if Finding Trash Panda?
