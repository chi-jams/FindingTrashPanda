
Usage Instructions:

Everything should be pretty self explanatory, the user needs to
log in with an email, and can interact with pandas using NFC.

Known bugs:

No known bugs
